<template>
    <div class="home row">
        <div class="col-md-3">
            <span class="hipster img-fluid rounded"></span>
        </div>
        <div class="col-md-9">
            <h1 class="display-4" v-text="$t('home.title')">Welcome, Java Hipster!</h1>
            <p class="lead" v-text="$t('home.subtitle')">This is your homepage</p>

            <div>
                <div class="alert alert-success" v-if="authenticated">
                    <span v-if="username" v-text="$t('home.logged.message', { 'username': username})">You are logged in as user "{{username}}"</span>
                </div>

                <div class="alert alert-warning" v-if="!authenticated">
                    <span v-text="$t('global.messages.info.authenticated.prefix')">If you want to </span>
                    <a class="alert-link" v-on:click="openLogin()" v-text="$t('global.messages.info.authenticated.link')">sign in</a><span v-html="$t('global.messages.info.authenticated.suffix')">, you can try the default accounts:<br/>- Administrator (login="admin" and password="admin") <br/>- User (login="user" and password="user").</span>
                </div>
                <div class="alert alert-warning" v-if="!authenticated">
                    <span v-text="$t('global.messages.info.register.noaccount')">You don't have an account yet?</span>&nbsp;
                    <router-link class="alert-link" to="/register" v-text="$t('global.messages.info.register.link')">Register a new account</router-link>
                </div>
                <div class="alert alert-success" v-if="authenticated">
                    <!--<span v-if="authorities" v-text="$t('home.logged.message', { 'authorities': authorities})">You are logged in as user "{{authorities}}"</span> -->
                   Ingrese el Rol de Usuario que va a trabajar

                    
                       
                            <b-form-select
                                :options="authorities"
                                text-field="roles"
                                value-field="id" :id="`rol-${i}`" 
                                 @change="setRuta"
                                >
                                
                              
                            </b-form-select>

                           
                       
                </div>

                <div v-if="authenticated">
                 <button  v-on:click="entrar" type="submit" id="save-entity" 
                    class="btn btn-primary"
                    :disabled="this.submitStatus === 'PENDING'"
                    >
                         <b-icon-person-lines-fill></b-icon-person-lines-fill>&nbsp;<span>Ingresar</span>
                    </button>
                </div>


 


                 
                  
            </div>

        </div>
    </div>
</template>


<script lang="ts" src="./home.component.ts">
</script>

